// db/init.js — สร้างตาราง SQLite ทั้งหมด
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const DB_PATH = process.env.DB_PATH || './db/tracker.db';

// สร้างโฟลเดอร์ถ้าไม่มี
const dir = path.dirname(DB_PATH);
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new Database(DB_PATH);

// เปิด WAL mode เพื่อ performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─── สร้างตาราง ───────────────────────────────────────────────────────────
db.exec(`
  -- บัญชี TikTok Shop แต่ละช่อง
  CREATE TABLE IF NOT EXISTS accounts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    shop_id     TEXT    NOT NULL UNIQUE,
    shop_name   TEXT    NOT NULL,
    access_token      TEXT NOT NULL,
    refresh_token     TEXT NOT NULL,
    token_expires_at  INTEGER NOT NULL,     -- Unix timestamp
    is_active   INTEGER DEFAULT 1,
    created_at  INTEGER DEFAULT (strftime('%s','now')),
    updated_at  INTEGER DEFAULT (strftime('%s','now'))
  );

  -- ออเดอร์ทั้งหมด
  CREATE TABLE IF NOT EXISTS orders (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id      INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    order_id        TEXT    NOT NULL,        -- TikTok Order ID
    order_status    TEXT    NOT NULL,         -- UNPAID / AWAITING_SHIPMENT / SHIPPED / DELIVERED / CANCELLED / etc.
    payment_status  TEXT,
    buyer_name      TEXT,
    total_amount    REAL,
    currency        TEXT    DEFAULT 'THB',
    item_count      INTEGER DEFAULT 0,
    items_json      TEXT    DEFAULT '[]',     -- JSON array ของสินค้า
    tracking_number TEXT,
    shipping_provider TEXT,
    note            TEXT    DEFAULT '',
    raw_json        TEXT,                     -- เก็บ raw response จาก TikTok
    first_seen_at   INTEGER DEFAULT (strftime('%s','now')),
    last_updated_at INTEGER DEFAULT (strftime('%s','now')),
    UNIQUE(account_id, order_id)
  );

  -- ประวัติการเปลี่ยนสถานะ
  CREATE TABLE IF NOT EXISTS order_history (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id    TEXT    NOT NULL,
    account_id  INTEGER NOT NULL,
    old_status  TEXT,
    new_status  TEXT    NOT NULL,
    changed_at  INTEGER DEFAULT (strftime('%s','now')),
    note        TEXT
  );

  -- log การดึงข้อมูล
  CREATE TABLE IF NOT EXISTS sync_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id  INTEGER,
    status      TEXT    NOT NULL,    -- success / error
    orders_fetched INTEGER DEFAULT 0,
    orders_updated INTEGER DEFAULT 0,
    error_msg   TEXT,
    synced_at   INTEGER DEFAULT (strftime('%s','now'))
  );

  -- Index สำหรับ query เร็ว
  CREATE INDEX IF NOT EXISTS idx_orders_account    ON orders(account_id);
  CREATE INDEX IF NOT EXISTS idx_orders_status     ON orders(order_status);
  CREATE INDEX IF NOT EXISTS idx_orders_order_id   ON orders(order_id);
  CREATE INDEX IF NOT EXISTS idx_history_order     ON order_history(order_id);
`);

console.log('✅ Database initialized:', DB_PATH);

module.exports = db;
