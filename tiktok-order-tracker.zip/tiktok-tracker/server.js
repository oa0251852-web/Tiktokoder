// server.js — Main entry point
require('dotenv').config();
const express   = require('express');
const http      = require('http');
const { Server } = require('socket.io');
const cors      = require('cors');
const path      = require('path');

const db   = require('./db/init');
const sync = require('./services/sync');
const api  = require('./routes/api');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, { cors: { origin: '*' } });

const PORT = process.env.PORT || 3000;

// ─── Middleware ────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── Routes ───────────────────────────────────────────────────────────────
app.use('/api', api(db));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ─── Socket.IO ────────────────────────────────────────────────────────────
io.on('connection', socket => {
  console.log('🔌 Client connected:', socket.id);

  // ส่งสถานะล่าสุดให้ client ใหม่
  const accounts = db.prepare('SELECT id, shop_name, shop_id FROM accounts WHERE is_active=1').all();
  const stats = db.prepare('SELECT order_status, COUNT(*) n FROM orders GROUP BY order_status').all();
  socket.emit('init', { accounts, stats });

  socket.on('disconnect', () => {
    console.log('🔌 Client disconnected:', socket.id);
  });

  // Manual sync request จาก client
  socket.on('sync:request', () => {
    sync.syncAll().catch(console.error);
  });
});

// ─── Init sync ────────────────────────────────────────────────────────────
sync.init(db, io);
sync.startScheduler();

// ─── Start ────────────────────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log(`\n🚀 TikTok Order Tracker`);
  console.log(`   URL:      http://localhost:${PORT}`);
  console.log(`   Webhook:  http://localhost:${PORT}/api/webhook`);
  console.log(`   Interval: ${process.env.POLL_INTERVAL_MINUTES || 5} minutes\n`);
});

process.on('unhandledRejection', (reason) => {
  console.error('Unhandled rejection:', reason);
});
