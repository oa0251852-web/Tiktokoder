# TikTok Order Tracker 🚀

ระบบติดตามออเดอร์จาก TikTok Shop API แบบ Real-time รองรับหลายบัญชี

## Architecture

```
TikTok Shop API
    │
    ├── Webhook (Order Status Update)  ← Push realtime จาก TikTok
    └── Polling API (ทุก 5 นาที)      ← Pull ออเดอร์ใหม่
          │
          ▼
    Node.js + Express + SQLite
          │
          ├── Socket.IO ──→ Browser (realtime update)
          └── REST API  ──→ Frontend Dashboard
```

## การติดตั้ง

### 1. Clone & Install
```bash
npm install
```

### 2. ตั้งค่า .env
```bash
cp .env.example .env
```

แก้ไขไฟล์ `.env`:
```
TIKTOK_APP_KEY=your_app_key
TIKTOK_APP_SECRET=your_app_secret
TIKTOK_REDIRECT_URI=http://localhost:3000/api/auth/callback
POLL_INTERVAL_MINUTES=5
```

### 3. Init Database
```bash
node db/init.js
```

### 4. Run
```bash
npm start
# หรือ dev mode:
npm run dev
```

เปิด http://localhost:3000

---

## ตั้งค่า TikTok Developer Portal

1. ไปที่ https://partner.tiktokshop.com/
2. สร้าง App ใหม่
3. เพิ่ม **Redirect URI**: `http://your-server.com/api/auth/callback`
4. เปิด Permissions:
   - `order.data.bind`
   - `reverse_order.data.bind`
5. ตั้ง **Webhook URL**: `http://your-server.com/api/webhook`
6. Subscribe events:
   - `ORDER_STATUS_CHANGE`
   - `REVERSE_ORDER_STATUS_CHANGE`
7. Copy `App Key` และ `App Secret` ใส่ `.env`

---

## API Endpoints

| Method | Path | คำอธิบาย |
|--------|------|----------|
| GET | `/api/auth/url` | รับ OAuth URL |
| GET | `/api/auth/callback` | TikTok callback |
| GET | `/api/accounts` | รายการบัญชี |
| POST | `/api/accounts/:id/sync` | Sync บัญชีเดียว |
| POST | `/api/sync/all` | Sync ทุกบัญชี |
| GET | `/api/orders` | รายการออเดอร์ (filter, search, paginate) |
| GET | `/api/orders/:id` | รายละเอียด + history |
| PATCH | `/api/orders/:id/note` | บันทึกหมายเหตุ |
| GET | `/api/stats` | สถิติ |
| POST | `/api/webhook` | รับ webhook จาก TikTok |
| GET | `/api/logs` | Sync logs |

---

## Deploy บน Production

### Railway (แนะนำ)
```bash
railway login
railway init
railway up
```
แล้วตั้ง Environment Variables ใน Railway dashboard

### Render
1. Connect GitHub repo
2. Set environment variables
3. Deploy

### VPS (Ubuntu)
```bash
npm install pm2 -g
pm2 start server.js --name tiktok-tracker
pm2 save
```

---

## Flow จาก TikTok Docs

### Order Status Flow
```
Buyer ซื้อ → Webhook: ORDER_STATUS_CHANGE
                │
                ▼
         API: Get Order Details
                │
                ▼
         อัปเดต DB → Socket.IO → Dashboard
```

### Polling Flow (backup)
```
ทุก N นาที → API: Get Order List
                 │
                 ▼
            API: Get Order Details (batch 50)
                 │
                 ▼
            Upsert DB → แจ้ง status change ถ้ามี
```
