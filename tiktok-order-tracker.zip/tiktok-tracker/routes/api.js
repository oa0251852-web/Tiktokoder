// routes/api.js
const express = require('express');
const crypto  = require('crypto');
const tiktok  = require('../services/tiktok');
const sync    = require('../services/sync');

module.exports = function (db) {
  const router = express.Router();

  // ─── Helper ───────────────────────────────────────────────────────────
  const ok  = (res, data) => res.json({ ok: true,  data });
  const err = (res, msg, code = 400) => res.status(code).json({ ok: false, error: msg });

  // ─── AUTH ──────────────────────────────────────────────────────────────
  // GET /api/auth/url — รับ link สำหรับ OAuth
  router.get('/auth/url', (req, res) => {
    const state = crypto.randomBytes(8).toString('hex');
    const url   = tiktok.getAuthURL(state);
    ok(res, { url, state });
  });

  // GET /api/auth/callback — TikTok redirect มาที่นี่
  router.get('/auth/callback', async (req, res) => {
    const { code, shop_id } = req.query;
    if (!code) return err(res, 'No auth code');

    try {
      const tokens = await tiktok.exchangeCode(code);
      const shops  = await tiktok.getShopList(tokens.access_token);

      // บันทึกทุก shop ที่ได้มา
      const insertShop = db.prepare(`
        INSERT INTO accounts(shop_id, shop_name, access_token, refresh_token, token_expires_at)
        VALUES(?,?,?,?,?)
        ON CONFLICT(shop_id) DO UPDATE SET
          access_token=excluded.access_token,
          refresh_token=excluded.refresh_token,
          token_expires_at=excluded.token_expires_at,
          is_active=1,
          updated_at=strftime('%s','now')
      `);

      const expiry = Math.floor(Date.now() / 1000) + (tokens.access_token_expire_in || 86400);

      for (const shop of shops) {
        insertShop.run(
          shop.shop_id,
          shop.shop_name || 'Unknown Shop',
          tokens.access_token,
          tokens.refresh_token,
          expiry
        );
      }

      // Sync ทันที (background)
      sync.syncAll().catch(console.error);

      // Redirect กลับ frontend
      res.redirect('/?connected=1');
    } catch (e) {
      console.error('Auth callback error:', e.message);
      res.redirect('/?error=' + encodeURIComponent(e.message));
    }
  });

  // ─── ACCOUNTS ──────────────────────────────────────────────────────────
  // GET /api/accounts
  router.get('/accounts', (req, res) => {
    const accounts = db.prepare(`
      SELECT id, shop_id, shop_name, is_active, created_at, updated_at,
             token_expires_at,
             (SELECT COUNT(*) FROM orders WHERE account_id=accounts.id) as order_count,
             (SELECT COUNT(*) FROM orders WHERE account_id=accounts.id AND order_status NOT IN ('DELIVERED','COMPLETED','CANCELLED')) as active_count
      FROM accounts ORDER BY created_at DESC
    `).all();
    ok(res, accounts);
  });

  // DELETE /api/accounts/:id
  router.delete('/accounts/:id', (req, res) => {
    db.prepare('UPDATE accounts SET is_active=0 WHERE id=?').run(req.params.id);
    ok(res, { removed: true });
  });

  // POST /api/accounts/:id/sync — Sync เฉพาะบัญชีนั้น
  router.post('/accounts/:id/sync', async (req, res) => {
    const account = db.prepare('SELECT * FROM accounts WHERE id=?').get(req.params.id);
    if (!account) return err(res, 'Account not found', 404);
    try {
      const result = await sync.syncAccount(account);
      ok(res, result);
    } catch (e) {
      err(res, e.message);
    }
  });

  // POST /api/sync/all — Sync ทุกบัญชี
  router.post('/sync/all', async (req, res) => {
    sync.syncAll().catch(console.error); // background
    ok(res, { message: 'Sync started' });
  });

  // ─── ORDERS ────────────────────────────────────────────────────────────
  // GET /api/orders
  router.get('/orders', (req, res) => {
    const {
      account_id, status, search, page = 1,
      limit = 50, sort = 'last_updated_at', order = 'DESC'
    } = req.query;

    const safeSort  = ['last_updated_at','first_seen_at','total_amount','order_id'].includes(sort) ? sort : 'last_updated_at';
    const safeOrder = order === 'ASC' ? 'ASC' : 'DESC';
    const offset    = (parseInt(page) - 1) * parseInt(limit);

    let where = '1=1';
    const params = [];

    if (account_id) { where += ' AND o.account_id=?'; params.push(account_id); }
    if (status && status !== 'ALL') { where += ' AND o.order_status=?'; params.push(status); }
    if (search) {
      where += ' AND (o.order_id LIKE ? OR o.buyer_name LIKE ? OR o.tracking_number LIKE ? OR o.items_json LIKE ?)';
      const q = `%${search}%`;
      params.push(q, q, q, q);
    }

    const rows = db.prepare(`
      SELECT o.*, a.shop_name, a.shop_id
      FROM orders o
      JOIN accounts a ON a.id = o.account_id
      WHERE ${where}
      ORDER BY o.${safeSort} ${safeOrder}
      LIMIT ? OFFSET ?
    `).all([...params, parseInt(limit), offset]);

    const total = db.prepare(`
      SELECT COUNT(*) as n FROM orders o WHERE ${where}
    `).get(params).n;

    // Parse items_json
    const data = rows.map(r => ({
      ...r,
      items: tryParse(r.items_json, []),
      status_label: tiktok.STATUS_MAP[r.order_status] || r.order_status,
      status_color: tiktok.STATUS_COLOR[r.order_status] || 'gray',
    }));

    ok(res, { orders: data, total, page: parseInt(page), limit: parseInt(limit) });
  });

  // GET /api/orders/:orderId — รายละเอียด + history
  router.get('/orders/:orderId', (req, res) => {
    const order = db.prepare(`
      SELECT o.*, a.shop_name FROM orders o
      JOIN accounts a ON a.id=o.account_id
      WHERE o.order_id=?
    `).get(req.params.orderId);

    if (!order) return err(res, 'Order not found', 404);

    const history = db.prepare(
      'SELECT * FROM order_history WHERE order_id=? ORDER BY changed_at DESC'
    ).all(req.params.orderId);

    ok(res, {
      ...order,
      items: tryParse(order.items_json, []),
      status_label: tiktok.STATUS_MAP[order.order_status] || order.order_status,
      status_color: tiktok.STATUS_COLOR[order.order_status] || 'gray',
      history,
    });
  });

  // PATCH /api/orders/:orderId/note
  router.patch('/orders/:orderId/note', (req, res) => {
    const { note } = req.body;
    db.prepare('UPDATE orders SET note=? WHERE order_id=?').run(note || '', req.params.orderId);
    ok(res, { updated: true });
  });

  // ─── STATS ─────────────────────────────────────────────────────────────
  // GET /api/stats
  router.get('/stats', (req, res) => {
    const { account_id } = req.query;
    const where = account_id ? 'WHERE account_id=?' : '';
    const params = account_id ? [account_id] : [];

    const total     = db.prepare(`SELECT COUNT(*) n FROM orders ${where}`).get(params).n;
    const byStatus  = db.prepare(`SELECT order_status, COUNT(*) n FROM orders ${where} GROUP BY order_status`).all(params);
    const today     = db.prepare(`SELECT COUNT(*) n FROM orders ${where ? where+' AND' : 'WHERE'} first_seen_at >= strftime('%s','now','-1 day')`).get(params).n;
    const recentSync = db.prepare('SELECT * FROM sync_logs ORDER BY synced_at DESC LIMIT 10').all();

    ok(res, {
      total,
      today,
      by_status: byStatus.map(s => ({
        status: s.order_status,
        count:  s.n,
        label:  tiktok.STATUS_MAP[s.order_status] || s.order_status,
        color:  tiktok.STATUS_COLOR[s.order_status] || 'gray',
      })),
      recent_sync: recentSync,
    });
  });

  // ─── WEBHOOK ───────────────────────────────────────────────────────────
  // POST /api/webhook — TikTok webhook endpoint
  router.post('/webhook', express.raw({ type: '*/*' }), (req, res) => {
    // Verify signature
    const signature = req.headers['x-tts-signature'] || '';
    const secret    = process.env.TIKTOK_APP_SECRET || '';
    const body      = req.body?.toString() || '';

    const expected = crypto
      .createHmac('sha256', secret)
      .update(body)
      .digest('hex');

    if (signature && signature !== expected) {
      console.warn('⚠️  Webhook signature mismatch');
      return res.status(401).json({ error: 'Invalid signature' });
    }

    // Parse and handle async
    try {
      const payload = JSON.parse(body);
      sync.handleWebhook(payload).catch(console.error);
    } catch { /* ignore parse errors */ }

    // ต้องตอบ 200 ทันทีหรือ TikTok จะ retry
    res.status(200).json({ code: 0 });
  });

  // ─── SYNC LOGS ─────────────────────────────────────────────────────────
  router.get('/logs', (req, res) => {
    const logs = db.prepare(`
      SELECT l.*, a.shop_name FROM sync_logs l
      LEFT JOIN accounts a ON a.id = l.account_id
      ORDER BY l.synced_at DESC LIMIT 50
    `).all();
    ok(res, logs);
  });

  return router;
};

function tryParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}
