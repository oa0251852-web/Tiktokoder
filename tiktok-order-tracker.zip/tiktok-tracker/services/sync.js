// services/sync.js — Auto-sync engine
const cron = require('node-cron');
const tiktok = require('./tiktok');

let db;
let io; // socket.io instance
let isSyncing = false;

function init(database, socketio) {
  db = database;
  io = socketio;
}

// ─── Token Management ─────────────────────────────────────────────────────
function getAccount(accountId) {
  return db.prepare('SELECT * FROM accounts WHERE id = ?').get(accountId);
}

async function ensureValidToken(account) {
  const now = Math.floor(Date.now() / 1000);
  // Refresh if expires within 1 hour
  if (account.token_expires_at - now < 3600) {
    console.log(`🔄 Refreshing token for shop: ${account.shop_name}`);
    const newTokens = await tiktok.refreshToken(account.refresh_token);
    const updated = {
      access_token:     newTokens.access_token,
      refresh_token:    newTokens.refresh_token,
      token_expires_at: Math.floor(Date.now() / 1000) + newTokens.access_token_expire_in,
    };
    db.prepare(`
      UPDATE accounts SET access_token=?, refresh_token=?, token_expires_at=?, updated_at=strftime('%s','now')
      WHERE id=?
    `).run(updated.access_token, updated.refresh_token, updated.token_expires_at, account.id);
    return { ...account, ...updated };
  }
  return account;
}

// ─── Upsert Order ─────────────────────────────────────────────────────────
function upsertOrder(normalized) {
  const existing = db.prepare(
    'SELECT order_status FROM orders WHERE account_id=? AND order_id=?'
  ).get(normalized.account_id, normalized.order_id);

  if (existing) {
    const statusChanged = existing.order_status !== normalized.order_status;
    if (statusChanged) {
      // บันทึก history
      db.prepare(`
        INSERT INTO order_history(order_id, account_id, old_status, new_status)
        VALUES(?,?,?,?)
      `).run(normalized.order_id, normalized.account_id, existing.order_status, normalized.order_status);

      // แจ้ง frontend ทันที
      if (io) {
        io.emit('order:status_changed', {
          order_id:   normalized.order_id,
          account_id: normalized.account_id,
          old_status: existing.order_status,
          new_status: normalized.order_status,
          label:      tiktok.STATUS_MAP[normalized.order_status] || normalized.order_status,
        });
      }
    }

    db.prepare(`
      UPDATE orders SET
        order_status=?, payment_status=?, buyer_name=?, total_amount=?,
        currency=?, item_count=?, items_json=?, tracking_number=?,
        shipping_provider=?, raw_json=?, last_updated_at=?
      WHERE account_id=? AND order_id=?
    `).run(
      normalized.order_status, normalized.payment_status, normalized.buyer_name,
      normalized.total_amount, normalized.currency, normalized.item_count,
      normalized.items_json, normalized.tracking_number, normalized.shipping_provider,
      normalized.raw_json, normalized.last_updated_at,
      normalized.account_id, normalized.order_id
    );
    return statusChanged ? 'updated' : 'unchanged';
  } else {
    db.prepare(`
      INSERT INTO orders(
        account_id, order_id, order_status, payment_status, buyer_name,
        total_amount, currency, item_count, items_json, tracking_number,
        shipping_provider, raw_json, last_updated_at
      ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
    `).run(
      normalized.account_id, normalized.order_id, normalized.order_status,
      normalized.payment_status, normalized.buyer_name, normalized.total_amount,
      normalized.currency, normalized.item_count, normalized.items_json,
      normalized.tracking_number, normalized.shipping_provider,
      normalized.raw_json, normalized.last_updated_at
    );

    if (io) {
      io.emit('order:new', {
        order_id:   normalized.order_id,
        account_id: normalized.account_id,
        status:     normalized.order_status,
      });
    }
    return 'new';
  }
}

// ─── Sync one account ─────────────────────────────────────────────────────
async function syncAccount(account) {
  account = await ensureValidToken(account);
  const { access_token, shop_id, id: accountId, shop_name } = account;

  console.log(`📦 Syncing: ${shop_name} (${shop_id})`);

  let fetched = 0, updated = 0, created = 0;

  try {
    // ดึงออเดอร์ 7 วันย้อนหลัง (หรือ 24 ชม. สำหรับ routine sync)
    const isFirstSync = !db.prepare(
      'SELECT id FROM orders WHERE account_id=? LIMIT 1'
    ).get(accountId);

    const createTimeFrom = isFirstSync
      ? Math.floor(Date.now() / 1000) - 7 * 24 * 3600   // 7 วัน
      : Math.floor(Date.now() / 1000) - 24 * 3600;       // 24 ชม.

    // ดึง order list
    const orders = await tiktok.fetchOrders(access_token, shop_id, {
      createTimeFrom,
      pageSize: 50,
    });

    if (!orders.length) {
      console.log(`  └ ${shop_name}: ไม่มีออเดอร์ใหม่`);
      return { fetched: 0, updated: 0, created: 0 };
    }

    // ดึง detail (batch 50)
    const orderIds = orders.map(o => o.order_id);
    const details = await tiktok.fetchOrderDetail(access_token, shop_id, orderIds);
    fetched = details.length;

    // Upsert ทีละอัน
    for (const raw of details) {
      const normalized = tiktok.normalizeOrder(raw, accountId);
      const result = upsertOrder(normalized);
      if (result === 'updated') updated++;
      if (result === 'new')     created++;
    }

    // Log
    db.prepare(`
      INSERT INTO sync_logs(account_id, status, orders_fetched, orders_updated)
      VALUES(?,?,?,?)
    `).run(accountId, 'success', fetched, updated + created);

    console.log(`  └ ${shop_name}: ${fetched} ออเดอร์, ใหม่ ${created}, อัปเดต ${updated}`);

    // Emit stats update
    if (io) io.emit('sync:complete', { account_id: accountId, shop_name, fetched, updated, created });

    return { fetched, updated, created };

  } catch (err) {
    console.error(`  ✗ ${shop_name}:`, err.message);
    db.prepare(`
      INSERT INTO sync_logs(account_id, status, error_msg)
      VALUES(?,?,?)
    `).run(accountId, 'error', err.message);

    if (io) io.emit('sync:error', { account_id: accountId, shop_name, error: err.message });
    throw err;
  }
}

// ─── Sync all active accounts ─────────────────────────────────────────────
async function syncAll() {
  if (isSyncing) { console.log('⏭  Sync already running, skipping'); return; }
  isSyncing = true;
  const accounts = db.prepare('SELECT * FROM accounts WHERE is_active=1').all();
  if (!accounts.length) { isSyncing = false; return; }

  console.log(`\n🔄 Auto-sync: ${accounts.length} บัญชี — ${new Date().toLocaleString('th-TH')}`);
  if (io) io.emit('sync:start', { count: accounts.length });

  const results = { total_fetched: 0, total_updated: 0, total_created: 0 };
  for (const acc of accounts) {
    try {
      const r = await syncAccount(acc);
      results.total_fetched  += r.fetched;
      results.total_updated  += r.updated;
      results.total_created  += r.created;
    } catch { /* continue other accounts */ }
  }

  isSyncing = false;
  console.log(`✅ Sync done: ${results.total_fetched} ออเดอร์, ใหม่ ${results.total_created}, อัปเดต ${results.total_updated}\n`);
}

// ─── Webhook handler (Order Status Update) ────────────────────────────────
async function handleWebhook(payload) {
  try {
    const { type, data } = payload;
    // type: ORDER_STATUS_CHANGE | REVERSE_ORDER_STATUS_CHANGE
    const shopId   = data?.shop_id;
    const orderId  = data?.order_id || data?.reverse_order_id;
    const newStatus = data?.order_status || data?.reverse_order_status;

    if (!shopId || !orderId) return;

    // หา account จาก shop_id
    const account = db.prepare('SELECT * FROM accounts WHERE shop_id=? AND is_active=1').get(shopId);
    if (!account) return;

    const acc = await ensureValidToken(account);

    // ดึง detail ทันที
    const details = await tiktok.fetchOrderDetail(acc.access_token, shopId, [orderId]);
    if (!details.length) return;

    const normalized = tiktok.normalizeOrder(details[0], account.id);
    upsertOrder(normalized);

    console.log(`🔔 Webhook ${type}: Order ${orderId} → ${newStatus}`);
  } catch (err) {
    console.error('Webhook handler error:', err.message);
  }
}

// ─── Cron scheduler ──────────────────────────────────────────────────────
function startScheduler() {
  const interval = parseInt(process.env.POLL_INTERVAL_MINUTES || '5');
  const cronExpr = `*/${interval} * * * *`;
  console.log(`⏰ Auto-sync every ${interval} minutes`);

  cron.schedule(cronExpr, () => {
    syncAll().catch(console.error);
  });

  // Initial sync 10s after startup
  setTimeout(() => syncAll().catch(console.error), 10000);
}

module.exports = { init, syncAll, syncAccount, handleWebhook, startScheduler };
