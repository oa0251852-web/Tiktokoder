// services/tiktok.js — TikTok Shop Open Platform API
const crypto = require('crypto');
const axios = require('axios');

const BASE_URL = 'https://open-api.tiktokglobal.com';
const AUTH_URL = 'https://auth.tiktok-shops.com';

const APP_KEY    = process.env.TIKTOK_APP_KEY;
const APP_SECRET = process.env.TIKTOK_APP_SECRET;

// ─── Order Status Map ──────────────────────────────────────────────────────
const STATUS_MAP = {
  UNPAID:              'รอชำระเงิน',
  AWAITING_SHIPMENT:   'รอจัดส่ง',
  AWAITING_COLLECTION: 'รอรับพัสดุ',
  IN_TRANSIT:          'กำลังจัดส่ง',
  DELIVERED:           'จัดส่งแล้ว',
  COMPLETED:           'สำเร็จ',
  CANCELLED:           'ยกเลิก',
  PARTIALLY_RETURNING: 'คืนสินค้าบางส่วน',
  FULLY_RETURNING:     'คืนสินค้าทั้งหมด',
  PARTIALLY_RETURNED:  'คืนแล้วบางส่วน',
  FULLY_RETURNED:      'คืนแล้วทั้งหมด',
};

const STATUS_COLOR = {
  UNPAID:              'amber',
  AWAITING_SHIPMENT:   'amber',
  AWAITING_COLLECTION: 'blue',
  IN_TRANSIT:          'blue',
  DELIVERED:           'green',
  COMPLETED:           'green',
  CANCELLED:           'red',
  PARTIALLY_RETURNING: 'orange',
  FULLY_RETURNING:     'orange',
  PARTIALLY_RETURNED:  'gray',
  FULLY_RETURNED:      'gray',
};

// ─── Signature (HMAC-SHA256) ───────────────────────────────────────────────
// TikTok Shop API v202309+ signature algorithm
function generateSign(path, params, body = '') {
  // 1. เรียง params ตาม key
  const sortedKeys = Object.keys(params).sort();
  let str = APP_SECRET + path;
  for (const key of sortedKeys) {
    str += key + params[key];
  }
  if (body) str += body;
  str += APP_SECRET;

  // 2. HMAC-SHA256
  return crypto
    .createHmac('sha256', APP_SECRET)
    .update(str)
    .digest('hex');
}

// ─── Build signed request ─────────────────────────────────────────────────
function buildRequest(path, extraParams = {}, body = null) {
  const timestamp = Math.floor(Date.now() / 1000).toString();
  const params = {
    app_key: APP_KEY,
    timestamp,
    ...extraParams,
  };

  const bodyStr = body ? JSON.stringify(body) : '';
  params.sign = generateSign(path, params, bodyStr);

  return { params, bodyStr };
}

// ─── HTTP helpers ─────────────────────────────────────────────────────────
async function apiGet(path, extraParams = {}) {
  const { params } = buildRequest(path, extraParams);
  const url = BASE_URL + path;

  try {
    const res = await axios.get(url, {
      params,
      timeout: 15000,
      headers: { 'Content-Type': 'application/json' },
    });
    if (res.data.code !== 0) {
      throw new Error(`TikTok API error ${res.data.code}: ${res.data.message}`);
    }
    return res.data.data;
  } catch (err) {
    if (err.response) {
      throw new Error(`HTTP ${err.response.status}: ${JSON.stringify(err.response.data)}`);
    }
    throw err;
  }
}

async function apiPost(path, body, extraParams = {}) {
  const bodyObj = body || {};
  const bodyStr = JSON.stringify(bodyObj);
  const { params } = buildRequest(path, extraParams, bodyStr);
  const url = BASE_URL + path;

  try {
    const res = await axios.post(url, bodyObj, {
      params,
      timeout: 15000,
      headers: { 'Content-Type': 'application/json' },
    });
    if (res.data.code !== 0) {
      throw new Error(`TikTok API error ${res.data.code}: ${res.data.message}`);
    }
    return res.data.data;
  } catch (err) {
    if (err.response) {
      throw new Error(`HTTP ${err.response.status}: ${JSON.stringify(err.response.data)}`);
    }
    throw err;
  }
}

// ─── OAuth 2.0 ────────────────────────────────────────────────────────────
function getAuthURL(state = '') {
  const params = new URLSearchParams({
    app_key: APP_KEY,
    redirect_uri: process.env.TIKTOK_REDIRECT_URI,
    state,
  });
  return `${AUTH_URL}/oauth/authorize?${params.toString()}`;
}

async function exchangeCode(code) {
  const res = await axios.post(`${AUTH_URL}/api/v2/token/get`, null, {
    params: {
      app_key: APP_KEY,
      app_secret: APP_SECRET,
      auth_code: code,
      grant_type: 'authorized_code',
    },
    timeout: 10000,
  });
  if (res.data.code !== 0) {
    throw new Error(`OAuth error: ${res.data.message}`);
  }
  return res.data.data; // { access_token, refresh_token, expires_in, seller_name, seller_base_region, ... }
}

async function refreshToken(refreshTok) {
  const res = await axios.post(`${AUTH_URL}/api/v2/token/refresh`, null, {
    params: {
      app_key: APP_KEY,
      app_secret: APP_SECRET,
      refresh_token: refreshTok,
      grant_type: 'refresh_token',
    },
    timeout: 10000,
  });
  if (res.data.code !== 0) {
    throw new Error(`Token refresh error: ${res.data.message}`);
  }
  return res.data.data;
}

async function getShopList(accessToken) {
  const data = await apiGet('/api/v2/seller/global_shops/get', {
    access_token: accessToken,
  });
  return data.shops || [];
}

// ─── Orders ───────────────────────────────────────────────────────────────

// ดึงออเดอร์ทั้งหมด (paginated) สำหรับ shop หนึ่ง
async function fetchOrders(accessToken, shopId, options = {}) {
  const {
    statuses = [],         // ถ้าว่างจะดึงทุก status
    pageSize = 50,
    createTimeFrom,        // Unix timestamp
    createTimeTo,
    updateTimeFrom,
    updateTimeTo,
  } = options;

  const allOrders = [];
  let pageToken = '';
  let hasMore = true;

  while (hasMore) {
    const body = {
      page_size: pageSize,
      sort_field: 'CREATE_TIME',
      sort_order: 'DESC',
    };

    if (statuses.length > 0) body.order_status = statuses;
    if (pageToken) body.page_token = pageToken;
    if (createTimeFrom) body.create_time_from = createTimeFrom;
    if (createTimeTo)   body.create_time_to = createTimeTo;
    if (updateTimeFrom) body.update_time_from = updateTimeFrom;
    if (updateTimeTo)   body.update_time_to = updateTimeTo;

    const data = await apiPost('/api/v202309/order/search', body, {
      access_token: accessToken,
      shop_id: shopId,
    });

    const orders = data.orders || [];
    allOrders.push(...orders);

    pageToken = data.next_page_token || '';
    hasMore = !!pageToken && orders.length >= pageSize;

    // Rate limit safety
    if (hasMore) await sleep(300);
  }

  return allOrders;
}

// ดึงรายละเอียดออเดอร์ (batch สูงสุด 50)
async function fetchOrderDetail(accessToken, shopId, orderIds) {
  if (!orderIds.length) return [];

  const chunks = chunkArray(orderIds, 50);
  const results = [];

  for (const chunk of chunks) {
    const data = await apiPost('/api/v202309/order/detail/query', {
      order_id_list: chunk,
      need_payment_info: true,
      need_recipient_address: false,
      need_line_items: true,
      need_shipment_info: true,
    }, {
      access_token: accessToken,
      shop_id: shopId,
    });

    results.push(...(data.orders || []));
    if (chunks.length > 1) await sleep(300);
  }

  return results;
}

// ─── Data Normalizer ──────────────────────────────────────────────────────
function normalizeOrder(raw, accountId) {
  const items = (raw.line_items || []).map(item => ({
    id: item.item_id,
    name: item.product_name,
    sku: item.seller_sku || '',
    quantity: item.quantity || 1,
    price: parseFloat(item.sale_price || 0),
    image: item.sku_image || '',
  }));

  const shipment = raw.shipment_providers?.[0] || {};

  return {
    account_id:       accountId,
    order_id:         raw.order_id,
    order_status:     raw.order_status || 'UNKNOWN',
    payment_status:   raw.payment?.payment_method || null,
    buyer_name:       raw.buyer_uid || 'Unknown',
    total_amount:     parseFloat(raw.payment?.total_amount || 0),
    currency:         raw.payment?.currency || 'THB',
    item_count:       items.length,
    items_json:       JSON.stringify(items),
    tracking_number:  shipment.tracking_number || null,
    shipping_provider: shipment.tracking_provider || null,
    raw_json:         JSON.stringify(raw),
    last_updated_at:  Math.floor(Date.now() / 1000),
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function chunkArray(arr, size) {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) chunks.push(arr.slice(i, i + size));
  return chunks;
}

module.exports = {
  getAuthURL,
  exchangeCode,
  refreshToken,
  getShopList,
  fetchOrders,
  fetchOrderDetail,
  normalizeOrder,
  STATUS_MAP,
  STATUS_COLOR,
};
